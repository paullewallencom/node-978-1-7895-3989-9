module.exports = {
  development: {
    host: "localhost",
    username: "root",
    password: "123456789",
    port: 3307,
    database: "PlansDb",
    dialect: "mysql"
  },
  production: {
    host: "localhost",
    username: "root",
    password: "123456789",
    port: 3307,
    database: "PlansDb",
    dialect: "mysql"
  }
}