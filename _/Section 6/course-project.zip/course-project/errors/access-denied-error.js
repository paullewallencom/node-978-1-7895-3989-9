module.exports = class AccessDeniedError {
    constructor(message) {
        this.message = message;
    }
}